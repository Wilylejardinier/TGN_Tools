AIFF
----

.. automodule:: mutagen.aiff

.. autoclass:: mutagen.aiff.AIFF(filename)
    :show-inheritance:
    :members:

.. autoclass:: mutagen.aiff.AIFFInfo()
    :members:
