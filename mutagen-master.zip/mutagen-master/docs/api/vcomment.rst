Vorbis Comment
==============

.. autoclass:: mutagen._vorbis.VComment()
    :show-inheritance:

.. autoclass:: mutagen._vorbis.VCommentDict()
    :show-inheritance:
