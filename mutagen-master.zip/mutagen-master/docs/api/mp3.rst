MP3
===

.. automodule:: mutagen.mp3

.. autoclass:: mutagen.mp3.MP3
    :show-inheritance:
    :members:

.. autoclass:: mutagen.mp3.MPEGInfo
    :show-inheritance:
    :members:

.. autoclass:: mutagen.mp3.BitrateMode
    :members:

.. autoclass:: mutagen.mp3.EasyMP3
    :show-inheritance:
    :members:
    :exclude-members: ID3
